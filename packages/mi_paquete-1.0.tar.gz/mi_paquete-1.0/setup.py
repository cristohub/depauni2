from setuptools import setup

setup( 
    name="mi_paquete",
    version="1.0",
    description= "ejemplo distribuir paquetes",
    author="Cristofer",
    packages=["mi_paquete", "mi_paquete.sub_paquete1"]
    
    )